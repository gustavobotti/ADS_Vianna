# PlanejadorFinanceiro

trabalho final segundo bimestre

## --------------------------

Definição 
Monte uma solução para a situação abaixo, utilize banco de dados e os conceitos vistos em sala,
thymeleaf, spring mvc, spring security, Springa data.
Problema:

“...Você sabia que o controle financeiro pessoal é apontado como a ferramenta de
maior importância para lidar melhor com seu dinheiro?
É fato que nem todo mundo sabe lidar com suas próprias finanças, principalmente
no Brasil. Todos os dias, milhares de pessoas passam pelo sufoco de não saber
como pagar as contas no final do mês ou pelas dívidas que já acumularam. Isso
tem muito a ver com a ausência de uma boa educação financeira, que culmina em
diversos outros fatores.
Ainda que essa seja a realidade, todos desejam ter um bom controle financeiro
pessoal e se livrar dos perrengues mensais. Pensando nisso, nós separamos
algumas dicas para te ajudar a controlar suas finanças.”



Sistema:
“Pensando neste cenário cria um sistema que permita o cadastro de usuários e que 
ele possa lançar suas despesas e receitas. Exiba também algumas informações que 
julgar necessário, tais como saldo da conta, total de despesas e receitas.
Cada despesa e receita pertence a uma categoria.
O administrador do sistema pode ter acesso a informações consolidadas dos 
usuários.”