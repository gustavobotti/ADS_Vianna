package br.vianna.aula.DespesasWeb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DespesasWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
