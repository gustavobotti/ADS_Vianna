/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.vianna.aula.DespesasWeb.config.security.service;

import br.vianna.aula.DespesasWeb.config.security.model.UserLogado;
import br.vianna.aula.DespesasWeb.dao.UsuarioDAO;
import br.vianna.aula.DespesasWeb.model.Usuario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

/**
 *
 * @author Gustavo Botti
 */
@Service
public class UserService implements UserDetailsService{
    
    @Autowired
    UsuarioDAO uDao;
    
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException{
        
        Usuario u = uDao.findByLogin(username);
        
        if (u == null){
            throw new UsernameNotFoundException("Usuário não existe");
        }
        
        return new UserLogado(u);
    }
    
}
