package br.vianna.aula.DespesasWeb;

import br.vianna.aula.DespesasWeb.dao.CategoriaDAO;
import br.vianna.aula.DespesasWeb.dao.UsuarioDAO;
import br.vianna.aula.DespesasWeb.dao.LancamentoDAO;
import br.vianna.aula.DespesasWeb.model.Categoria;
import br.vianna.aula.DespesasWeb.model.Usuario;
import br.vianna.aula.DespesasWeb.model.Lancamento;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.crypto.password.PasswordEncoder;

@SpringBootApplication
public class DespesasWebApplication implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication.run(DespesasWebApplication.class, args);
    }

    @Autowired
    LancamentoDAO lDao;

    @Autowired
    UsuarioDAO uDao;

    @Autowired
    CategoriaDAO cDao;
    
    @Autowired
    PasswordEncoder pass;

    @Override
    public void run(String... args) throws Exception {
        System.out.println("Servidor iniciado");
        
        Usuario u = Usuario.builder()
                .login("ze").senha(pass.encode("123")).lancamentos(null).categorias(null).saldo(0)
                .build();
        uDao.save(u);      
        Usuario uu = Usuario.builder()
                .login("pedrin").senha(pass.encode("123")).lancamentos(null).categorias(null).saldo(0)
                .build();
        uDao.save(uu);

        Categoria c = new Categoria(0, "Moradia", null, null, true);
        Categoria c1 = new Categoria(0, "Salário", null, null, false);
        
        cDao.save(c);
        cDao.save(c1);
        
    }

}
