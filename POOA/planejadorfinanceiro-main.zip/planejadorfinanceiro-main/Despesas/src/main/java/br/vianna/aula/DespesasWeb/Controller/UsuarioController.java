/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.vianna.aula.DespesasWeb.Controller;

import br.vianna.aula.DespesasWeb.dao.CategoriaDAO;
import br.vianna.aula.DespesasWeb.dao.LancamentoDAO;
import br.vianna.aula.DespesasWeb.dao.UsuarioDAO;
import br.vianna.aula.DespesasWeb.model.Usuario;
import br.vianna.aula.DespesasWeb.model.dto.LoginDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping({"/signup"})
public class UsuarioController {
    
    @Autowired
    UsuarioDAO uDao;
    @Autowired
    CategoriaDAO cDao;
    @Autowired
    LancamentoDAO lDao;
    @Autowired
    PasswordEncoder pass;
    
    @GetMapping({""})
    public String newSignUpPage( Model model){
        
        model.addAttribute("usuario", new LoginDTO( "", ""));
        
        return "signup";
    }
    
    
    @Transactional
    @PostMapping({""})
    public String saveUsuarioPage( @ModelAttribute LoginDTO usuario){        
               
         Usuario u = Usuario.builder()
                .login(usuario.getLogin())
                .senha(pass.encode(usuario.getSenha()))
                .build();
        
        u = uDao.save(u);
        
        u = uDao.getById(u.getId());
         
        uDao.save(u);
        
        return "redirect:/login";
    }
    

}
