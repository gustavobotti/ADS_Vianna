/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.vianna.aula.DespesasWeb.Controller;

import br.vianna.aula.DespesasWeb.config.security.model.UserLogado;
import br.vianna.aula.DespesasWeb.dao.CategoriaDAO;
import br.vianna.aula.DespesasWeb.dao.LancamentoDAO;
import br.vianna.aula.DespesasWeb.dao.UsuarioDAO;
import br.vianna.aula.DespesasWeb.model.Categoria;
import br.vianna.aula.DespesasWeb.model.Usuario;
import br.vianna.aula.DespesasWeb.model.dto.CategoriaCreateDTO;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/categoria")
public class CategoriaController {
    
    @Autowired
    UsuarioDAO uDao;
    @Autowired
    CategoriaDAO cDao;
    @Autowired
    LancamentoDAO lDao;
       
    @Transactional
    @GetMapping({"","/{filtro}"})
    public String categoriaPage(@PathVariable(required = false) String filtro, Model model, Authentication auth){        
        UserLogado u = (UserLogado) auth.getPrincipal();
        Usuario user = u.getUsuario();
        
        model.addAttribute("listaCategoria", cDao.findByUsuario(user));
        return "categoria";
    }
    
    @GetMapping({"/new"})
    public String newCategoriaPage( Model model){
        
        model.addAttribute("categoria", new CategoriaCreateDTO(0,0,"","", false));
        
        return "newCategoria";
    }
    
    @Transactional
    @PostMapping({""})
    public String saveCategoriaPage( @ModelAttribute CategoriaCreateDTO categoria, Authentication auth){       
        
                UserLogado u = (UserLogado) auth.getPrincipal();
                Usuario user = u.getUsuario();
                
        
                Categoria c = Categoria.builder()
                .nome(categoria.getNome())
                .ehDespesa(categoria.isEhDespesa())
                .build();
               
        
        c.setUsuario(user);
        
        c = cDao.save(c);
        
        c = cDao.getById(c.getId());
         
        cDao.save(c); 
        
        return "redirect:/categoria";
    }
    

}
