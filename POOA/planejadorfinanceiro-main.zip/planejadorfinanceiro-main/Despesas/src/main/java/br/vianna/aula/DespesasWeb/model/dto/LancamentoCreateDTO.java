/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.vianna.aula.DespesasWeb.model.dto;

import br.vianna.aula.DespesasWeb.model.Categoria;
import br.vianna.aula.DespesasWeb.model.Usuario;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

/**
 *
 * @author Gustavo Botti
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LancamentoCreateDTO {
    
    private int Id;
        
    private String descricao;

    private double valor;
    
    private int categoria, usuario;
    
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date data;
        
    private boolean ehDespesa;
    
}
