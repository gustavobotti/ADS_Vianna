/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.vianna.aula.DespesasWeb.dao;

import br.vianna.aula.DespesasWeb.model.Usuario;
import br.vianna.aula.DespesasWeb.model.dto.PessoaDTO;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

/**
 *
 * @author usuário
 */
public interface UsuarioDAO extends JpaRepository<Usuario, Integer>{

    String src = "br.vianna.aula.DespesasWeb.model.dto.";
    
    public Usuario findByLoginAndSenha(String login, String senha);
    public Usuario findByLogin(String login);

    @Query("select new "+src+"PessoaDTO(u.id, u.login) from Usuario u")
    public List<PessoaDTO> getAllUsuarios();
            

}
