/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.vianna.aula.DespesasWeb.Controller;

import br.vianna.aula.DespesasWeb.config.security.model.UserLogado;
import br.vianna.aula.DespesasWeb.dao.CategoriaDAO;
import br.vianna.aula.DespesasWeb.dao.LancamentoDAO;
import br.vianna.aula.DespesasWeb.dao.UsuarioDAO;
import br.vianna.aula.DespesasWeb.model.Categoria;
import br.vianna.aula.DespesasWeb.model.Lancamento;
import br.vianna.aula.DespesasWeb.model.Usuario;
import java.io.IOException;
import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot3D;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.util.Rotation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/charts")
public class ChartController {
    
    @Autowired
    UsuarioDAO uDao;
    @Autowired
    CategoriaDAO cDao;
    @Autowired
    LancamentoDAO lDao;
    Authentication auth;
        
    @RequestMapping(value = "/piechart", method = RequestMethod.GET)
    public void drawPieChart(HttpServletResponse response){
        response.setContentType("image/png");
        PieDataset pdSet = createDataSet();
        
        JFreeChart chart = createChart(pdSet, "Pie Chart Categorias");
        
        try{
            ChartUtilities.writeChartAsPNG(response.getOutputStream(), chart, 750, 400);
            response.getOutputStream().close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }   
   
    
//    private PieDataset createDataSet(){
//        DefaultPieDataset dpd = new DefaultPieDataset();
//        dpd.setValue("Alimentação", 21);
//        dpd.setValue("Luz", 30);
//        dpd.setValue("Moradia", 40);
//        dpd.setValue("Others", 9);
//        return dpd;
//    }
    
    private PieDataset createDataSet(){
        DefaultPieDataset dpd = new DefaultPieDataset();
        
        UserLogado u = (UserLogado) auth.getPrincipal();
        Usuario user = u.getUsuario();        
        List<Categoria> categorias = cDao.findByUsuario(user);  
        
        double valorTotalUsuario = 0;
        
        
        List<Lancamento> lancamentosDoUsuario = lDao.findByUsuario(user);             
        for(Lancamento l : lancamentosDoUsuario){                
             valorTotalUsuario = valorTotalUsuario + l.getValor();
        }                   

        for(Categoria c : categorias){               
            List<Lancamento> lancamentos = lDao.findByCategoriaAndUsuario(c, user); 
            double valorTotalCategoria = 0;
            for(Lancamento l : lancamentos){                
                valorTotalCategoria = valorTotalCategoria + l.getValor();
            }
            valorTotalCategoria = (valorTotalCategoria*100)/valorTotalUsuario;
            dpd.setValue(c.getNome(), valorTotalCategoria);
        }
        return dpd;
    }
    
    
    
    
    private JFreeChart createChart(PieDataset pdSet, String chartTitle){
        JFreeChart chart = ChartFactory.createPieChart3D(chartTitle, pdSet, true, true, false);
        PiePlot3D plot = (PiePlot3D) chart.getPlot();
        plot.setStartAngle(290);
        plot.setDirection(Rotation.CLOCKWISE);
        plot.setForegroundAlpha(0.5f);
        return chart;
    }
    
    //////////////////////// pie end
    /////////////////////// bar starts
    
//    @RequestMapping(value = "/barchart", method = RequestMethod.GET)
//    public void drawBarChart(HttpServletResponse response){
//        response.setContentType("image/png");
//        PieDataset pdSet = createDataSet();
//        
//        JFreeChart chart = createChart(pdSet, "Pie Chart");
//        
//        try{
//            ChartUtilities.writeChartAsPNG(response.getOutputStream(), chart, 750, 400);
//            response.getOutputStream().close();
//        } catch (IOException ex) {
//            ex.printStackTrace();
//        }
//    }   
//   
//    
//    private PieDataset createDataSet(){
//        DefaultPieDataset dpd = new DefaultPieDataset();
//        dpd.setValue("Mac", 21);
//        dpd.setValue("Linux", 30);
//        dpd.setValue("Windows", 40);
//        dpd.setValue("Others", 9);
//        return dpd;
//    }
//    
//    
//    private JFreeChart createChart(PieDataset pdSet, String chartTitle){
//        JFreeChart chart = ChartFactory.createPieChart3D(chartTitle, pdSet, true, true, false);
//        PiePlot3D plot = (PiePlot3D) chart.getPlot();
//        plot.setStartAngle(290);
//        plot.setDirection(Rotation.CLOCKWISE);
//        plot.setForegroundAlpha(0.5f);
//        return chart;
//    }
    
    
       
}
