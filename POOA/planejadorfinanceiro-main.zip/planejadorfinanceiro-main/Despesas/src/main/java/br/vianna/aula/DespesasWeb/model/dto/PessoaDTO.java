/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.vianna.aula.DespesasWeb.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *
 * @author daves
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PessoaDTO {
    
    private int id;
    private String login;
}
