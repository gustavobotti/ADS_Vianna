/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.vianna.todo.model;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Gustavo Botti
 */
@Entity
public class Relatorio {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(nullable = false)
    private Date data;
    
    @Column(nullable = false)
    private double ganhoTotal;
    
    @Column(nullable = false)
    private double ganhoPlanos;   
    
    public Relatorio() {
    }

    public Relatorio(int id, Date data, double ganhoTotal, double ganhoPlanos) {
        this.id = id;
        this.data = data;
        this.ganhoTotal = ganhoTotal;
        this.ganhoPlanos = ganhoPlanos;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public double getGanhoTotal() {
        return ganhoTotal;
    }

    public void setGanhoTotal(double ganhoTotal) {
        this.ganhoTotal = ganhoTotal;
    }

    public double getGanhoPlanos() {
        return ganhoPlanos;
    }

    public void setGanhoPlanos(double ganhoPlanos) {
        this.ganhoPlanos = ganhoPlanos;
    }
    
    public String dataString(){
    
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                
        return sdf.format(data);
        
    }

    
}
