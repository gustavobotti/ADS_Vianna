/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.vianna.todo.controller.action.impl;

import br.edu.vianna.todo.controller.action.ICommanderAction;
import br.edu.vianna.todo.dao.impl.ExameDAO;
import br.edu.vianna.todo.model.Exame;
import br.edu.vianna.todo.util.AtendenteUtil;
import br.edu.vianna.todo.util.LoginUtil;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Gustavo Botti
 */
public class CallFinishExamePageAction implements ICommanderAction {

    @Override
    public void executa(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        try {
            LoginUtil.verificaLogado(request, response);
            AtendenteUtil.verificaLogado(request, response);
            
            List<Exame> exames = new ExameDAO().findAll();
            
            request.setAttribute("exames", exames);
            RequestDispatcher rd = request.getRequestDispatcher("template.jsp?pg=endExame");
            rd.forward(request, response);
        } catch (SQLException ex) {
            request.setAttribute("msgAviso", "Erro ao encontrar exames no banco!");
            new CallHomeLogadoPageAction().executa(request, response);
        }
    }
    
}
