/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.vianna.todo.controller.action.impl;

import br.edu.vianna.todo.controller.action.ICommanderAction;
import br.edu.vianna.todo.dao.impl.ExameDAO;
import br.edu.vianna.todo.dao.impl.RelatorioDAO;
import br.edu.vianna.todo.dao.impl.UsuarioDAO;
import br.edu.vianna.todo.model.Exame;
import br.edu.vianna.todo.model.Relatorio;
import br.edu.vianna.todo.model.Usuario;
import br.edu.vianna.todo.util.AdminUtil;
import br.edu.vianna.todo.util.LoginUtil;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang.time.DateUtils;

/**
 *
 * @author Gustavo Botti
 */
public class VerLucroAction implements ICommanderAction {

    @Override
    public void executa(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        
            LoginUtil.verificaLogado(request, response);
            AdminUtil.verificaLogado(request, response);
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        
        
        Relatorio relatorio = null;
        try {
            relatorio = new Relatorio(0, sdf.parse(request.getParameter("cpData")), 0, 0);
        } catch (ParseException ex) {
            request.setAttribute("msgAviso", "Data inválida!");
            new CallRelatorioPageAction().executa(request, response);
        }
        
        List<Exame> exames = null;
        try {
            exames = new ExameDAO().findAll( );
        } catch (SQLException ex) {
            request.setAttribute("msgAviso", "Não encontrou a lista!");
            new CallRelatorioPageAction().executa(request, response);
        }
        
        double ganhoTotal = 0;
        double ganhoPlanos = 0;
        Date dataRelatorio = null;
        Date dataInicioRelatorio = null;
        Date dataFimRelatorio = null;
        try {
            dataRelatorio = sdf.parse(request.getParameter("cpData"));
        } catch (ParseException ex) {
            request.setAttribute("msgAviso", "Data inválida!");
            new CallRelatorioPageAction().executa(request, response);
        }
        
        dataInicioRelatorio = DateUtils.addDays(dataRelatorio, -15);
        dataFimRelatorio = DateUtils.addDays(dataRelatorio, 15);
        
        for (Exame e : exames){
            if(e.getDataFinalizada() != null){
                if(e.getDataFinalizada().before(dataFimRelatorio) && e.getDataFinalizada().after(dataInicioRelatorio)){
                    ganhoTotal += e.getCusto();
                }
            }            
        }
        for (Exame e : exames){
            if(e.getDataFinalizada() != null && e.getUsuario().getPlanoSaude() != null){
                if(e.getDataFinalizada().before(dataFimRelatorio) && e.getDataFinalizada().after(dataInicioRelatorio)){
                    ganhoPlanos += e.getCusto();
                }
            }
        }
        relatorio.setGanhoTotal(ganhoTotal);       
        relatorio.setGanhoPlanos(ganhoPlanos);     
        
        try {
            new RelatorioDAO().inserir(relatorio);            
        } catch (SQLException ex) {
            request.setAttribute("msg", "Erro ao salvar o relatório!");
            new CallRelatorioPageAction().executa(request, response);
        }               
        
         
        request.setAttribute("exames", exames);              
        request.setAttribute("relatorio", relatorio);       
        
        request.setAttribute("msgAviso", "Relatório criado com sucesso!");
        
        new CallRelatorioPageAction().executa(request, response);
    }
    
}
