/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.vianna.todo.controller.action.impl;

import br.edu.vianna.todo.controller.action.ICommanderAction;
import br.edu.vianna.todo.dao.impl.ExameDAO;
import br.edu.vianna.todo.model.Exame;
import br.edu.vianna.todo.model.Usuario;
import br.edu.vianna.todo.util.LoginUtil;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Gustavo Botti
 */
public class CallResultadoPageAction implements ICommanderAction{

    @Override
    public void executa(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        try {
            LoginUtil.verificaLogado(request, response);
            
            int id = Integer.parseInt(request.getParameter("id"));
            
            Exame exame = new ExameDAO().findById(id);
            
            request.getSession().setAttribute("exame", exame);
            
            RequestDispatcher rd = request.getRequestDispatcher("template.jsp?pg=Resultado");
            
            rd.forward(request, response);
        } catch (SQLException ex) {
            
            request.setAttribute("msgAviso", "Exame não encontrado!");
                   
            new CallExameListPageAction().executa(request, response);
        }
    
    }    
    
}
