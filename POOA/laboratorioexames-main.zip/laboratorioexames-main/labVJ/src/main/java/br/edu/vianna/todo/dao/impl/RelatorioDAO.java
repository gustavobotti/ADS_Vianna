/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.vianna.todo.dao.impl;

import br.edu.vianna.todo.dao.GenericDao;
import br.edu.vianna.todo.model.Relatorio;
import br.edu.vianna.todo.model.Usuario;
import java.sql.SQLException;
import java.util.List;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;

/**
 *
 * @author victor
 */
public class RelatorioDAO extends GenericDao<Relatorio, Integer>{

    @Override
    public void inserir(Relatorio obj) throws SQLException {
        em.getTransaction().begin();
        em.persist(obj);
        em.getTransaction().commit();
    }

    @Override
    public void alterar(Relatorio obj) throws SQLException {
        em.getTransaction().begin();
        em.merge(obj);
        em.getTransaction().commit();
    }

    @Override
    public void apagar(Relatorio obj) throws SQLException {
        em.getTransaction().begin();
        em.remove(obj);
        em.getTransaction().commit();
    }

    @Override
    public Relatorio findById(Integer key) throws SQLException {
        return em.find(Relatorio.class, key);
    }

    @Override
    public List<Relatorio> findAll() throws SQLException {
        String consulta = "select r from Relatorio r";
        Query q = em.createQuery(consulta);
        
        return q.getResultList();
    } 
    
}
