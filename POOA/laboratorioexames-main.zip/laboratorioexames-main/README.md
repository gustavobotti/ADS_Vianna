Definição 

Monte uma solução para a situação abaixo, utilize banco de dados e os conceitos de jsp, servlet e MVC.

Problema: 

“...Um laboratório de análises clinicas realiza diversos exames ao longo do dia, cada 
exame com seu custo. 
Faça um programa que permita ao administrador cadastrar os exames realizados pelo laboratório. 
No exame deve conter informação do preço, descrição, tempo de jejum e tempo de entrega do exame. 
A empresa deve também registrar informações a respeito do cliente que irá realizar o exame (nome, telefone, sexo, endereço, cpf, entre outros). 
A atendente deve ser capaz de registrar os exames feitos pelos clientes além do preço do exame e do tempo de entrega e se o resultado já foi entregue. 
Se o cliente possuir plano de saúde o exame sai de graça. O cliente pode consultar seus exames pela web.
O administrador deve consulta no sistema o lucro mensal da empresa com os exames e quanto tem a receber de cada plano de saúde.”